import { App, Plugin, PluginSettingTab, Setting, Notice } from "obsidian";
import { importFromNotion, ImportOptions } from "./notionApiImporter";

/**
 * Settings interface for the Notion API importer. Right now we only expose the
 * integration token to the user. In the future you could add options to
 * control how select/multi‑select are mapped, whether to create a People
 * folder for mentions, and where attachments should be stored.
 */
interface NotionApiImporterSettings {
  notionToken: string;
}

const DEFAULT_SETTINGS: NotionApiImporterSettings = {
  notionToken: ""
};

export default class NotionApiImporterPlugin extends Plugin {
  settings: NotionApiImporterSettings;

  async onload() {
    await this.loadSettings();
    this.addRibbonIcon("download", "Import from Notion", async () => {
      await this.runImport();
    });
    this.addCommand({
      id: "notion-api-import",
      name: "Import from Notion API",
      callback: () => this.runImport()
    });
    this.addSettingTab(new NotionApiImporterSettingTab(this.app, this));
  }

  onunload() {
    // nothing to clean up
  }

  async runImport() {
    const token = this.settings.notionToken.trim();
    if (!token) {
      new Notice("Please configure your Notion integration token in the plugin settings.");
      return;
    }
    const vaultPath = this.app.vault.adapter.getBasePath();
    try {
      new Notice("Starting Notion import. This may take a while, check the log file for progress.");
      // Provide default options for the import. The vaultPath is required
      // internally so that attachments can be saved into the appropriate
      // directory. Attachments will be downloaded into a folder named
      // "attachments" in the root of your vault. Additional options can be
      // added here in the future (see ImportOptions in src/types.ts).
      const options: ImportOptions = {
        vaultPath,
        attachmentsDir: "attachments"
      };
      await importFromNotion(this.app, vaultPath, token, options);
      new Notice("Notion import finished");
    } catch (err) {
      console.error(err);
      new Notice(`Notion import failed: ${err}`);
    }
  }

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }
}

class NotionApiImporterSettingTab extends PluginSettingTab {
  plugin: NotionApiImporterPlugin;
  constructor(app: App, plugin: NotionApiImporterPlugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display(): void {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Notion API Importer Settings" });

    new Setting(containerEl)
      .setName("Notion Integration Token")
      .setDesc(
        "Create an internal integration in Notion, copy the secret, and paste it here. The importer uses this token to fetch your data via the Notion API."
      )
      .addText(text =>
        text
          .setPlaceholder("secret_…")
          .setValue(this.plugin.settings.notionToken)
          .onChange(async value => {
            this.plugin.settings.notionToken = value.trim();
            await this.plugin.saveSettings();
          })
      );
  }
}