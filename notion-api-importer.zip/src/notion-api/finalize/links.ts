import * as fs from "fs-extra";
import * as path from "path";

/**
 * After all pages and database rows have been rendered into Markdown files
 * there may still be unresolved link placeholders such as [[notion-id]]. This
 * function walks every markdown file in the vault and replaces each
 * placeholder with the final file name obtained from the registry map. When
 * mapping, the `.md` extension is stripped because Obsidian wikilinks do not
 * include extensions. Links to pages that could not be resolved are left
 * unchanged so the user can manually fix them later.
 */
export async function finalizeLinks(
  vaultPath: string,
  registry: Map<string, string>
): Promise<void> {
  const files: string[] = [];
  // Recursively collect all markdown files in the vault
  async function walk(dir: string) {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const entry of entries) {
      const p = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        await walk(p);
      } else if (entry.isFile() && entry.name.toLowerCase().endsWith(".md")) {
        files.push(p);
      }
    }
  }
  await walk(vaultPath);
  for (const filePath of files) {
    let content = await fs.readFile(filePath, "utf8");
    // Regex to find [[uuid]] style placeholders (including hyphens)
    const placeholderRegex = /\[\[([0-9a-fA-F-]{32,})\]\]/g;
    let match: RegExpExecArray | null;
    let replaced = false;
    const replacements: { id: string; link: string }[] = [];
    while ((match = placeholderRegex.exec(content))) {
      const id = match[1];
      const mapped = registry.get(id);
      if (mapped) {
        const link = mapped.replace(/\.md$/i, "");
        replacements.push({ id, link });
      }
    }
    for (const { id, link } of replacements) {
      const pattern = new RegExp(`\\[\\[${id}\\]\\]`, "g");
      content = content.replace(pattern, `[[${link}]]`);
      replaced = true;
    }
    if (replaced) {
      await fs.writeFile(filePath, content, "utf8");
    }
  }
}