import { Client } from "@notionhq/client";

/**
 * Construct a Notion client using the supplied integration token. We
 * explicitly set the API version to 2025‑09‑03 so the importer is prepared
 * for multi‑source databases and other breaking changes introduced in that
 * release【309647145213481†L69-L76】. If Notion introduces new versions in the
 * future you should update this constant accordingly.
 */
export function createNotionClient(token: string): Client {
  return new Client({
    auth: token,
    notionVersion: "2025-09-03"
  });
}