import { Client } from "@notionhq/client";
import { ImportOptions } from "../../types";
import { renderInline } from "./inline";
import { downloadFile } from "../files";
import { renderTable } from "./tables";

/**
 * Render an array of Notion blocks into Markdown. The function dispatches
 * individual block types to specialized handlers. Nested children are passed
 * recursively. A registry of Notion IDs to Obsidian file names is used to
 * resolve relation and mention links in a later pass.
 */
export async function renderBlocks(
  client: Client,
  blocks: any[],
  registry: Map<string, string>,
  options: ImportOptions,
  depth: number = 0
): Promise<string> {
  let md = "";
  for (const block of blocks) {
    md += await renderBlock(client, block, registry, options, depth);
  }
  return md;
}

async function renderBlock(
  client: Client,
  block: any,
  registry: Map<string, string>,
  options: ImportOptions,
  depth: number
): Promise<string> {
  const indent = "  ".repeat(depth);
  switch (block.type) {
    case "paragraph": {
      const text = renderInline(block.paragraph.rich_text || [], registry);
      return `${text}\n\n`;
    }
    case "heading_1": {
      const text = renderInline(block.heading_1.rich_text || [], registry);
      return `# ${text}\n\n`;
    }
    case "heading_2": {
      const text = renderInline(block.heading_2.rich_text || [], registry);
      return `## ${text}\n\n`;
    }
    case "heading_3": {
      const text = renderInline(block.heading_3.rich_text || [], registry);
      return `### ${text}\n\n`;
    }
    case "bulleted_list_item": {
      const text = renderInline(block.bulleted_list_item.rich_text || [], registry);
      let line = `${indent}- ${text}\n`;
      if (block.children && block.children.length > 0) {
        const childMd = await renderBlocks(client, block.children, registry, options, depth + 1);
        line += childMd;
      }
      return line;
    }
    case "numbered_list_item": {
      const text = renderInline(block.numbered_list_item.rich_text || [], registry);
      let line = `${indent}1. ${text}\n`;
      if (block.children && block.children.length > 0) {
        const childMd = await renderBlocks(client, block.children, registry, options, depth + 1);
        line += childMd;
      }
      return line;
    }
    case "to_do": {
      const text = renderInline(block.to_do.rich_text || [], registry);
      const checked = block.to_do.checked ? "x" : " ";
      let line = `${indent}- [${checked}] ${text}\n`;
      if (block.children && block.children.length > 0) {
        const childMd = await renderBlocks(client, block.children, registry, options, depth + 1);
        line += childMd;
      }
      return line;
    }
    case "toggle": {
      const text = renderInline(block.toggle.rich_text || [], registry);
      let line = `${indent}<details>\n${indent}<summary>${text}</summary>\n\n`;
      if (block.children && block.children.length > 0) {
        const childMd = await renderBlocks(client, block.children, registry, options, depth + 1);
        line += childMd;
      }
      line += `${indent}</details>\n\n`;
      return line;
    }
    case "quote": {
      const text = renderInline(block.quote.rich_text || [], registry);
      return `> ${text}\n\n`;
    }
    case "callout": {
      const text = renderInline(block.callout.rich_text || [], registry);
      // Notion callouts include an icon and color; we map to Obsidian callout syntax
      const emoji = block.callout.icon?.emoji;
      const calloutType = block.callout.color?.replace("_background", "");
      const prefix = emoji ? `[!${calloutType ?? "note"}]` : `[!${calloutType ?? "note"}]`;
      return `> ${prefix} ${text}\n\n`;
    }
    case "code": {
      const code = block.code.rich_text?.map((t: any) => t.plain_text).join("") ?? "";
      const lang = block.code.language || "";
      return `\`\`\`${lang}\n${code}\n\`\`\`\n\n`;
    }
    case "divider": {
      return `---\n\n`;
    }
    case "equation": {
      const expr = block.equation.expression;
      return `$${expr}$\n\n`;
    }
    case "table": {
      // Fetch children (table rows) if not already present
      let rows = block.children;
      if (!rows) {
        const res: any = await client.blocks.children.list({ block_id: block.id });
        rows = res.results;
      }
      const tableMd = await renderTable(client, block, rows, registry, options);
      return tableMd + "\n\n";
    }
    case "image": {
      // Download the image and embed it using Obsidian embed syntax. If
      // attachments are disabled we fallback to linking the external URL.
      const file = block.image;
      if (file.type === "file") {
        const path = await downloadFile(client, file, options);
        return `![](${path})\n\n`;
      } else if (file.type === "external") {
        return `![](${file.external.url})\n\n`;
      }
      return "";
    }
    case "file": {
      const fileData = block.file;
      if (fileData.type === "file") {
        const path = await downloadFile(client, fileData, options);
        return `![file](${path})\n\n`;
      } else if (fileData.type === "external") {
        return `[${fileData.external.url}](${fileData.external.url})\n\n`;
      }
      return "";
    }
    case "bookmark": {
      return `[${block.bookmark.url}](${block.bookmark.url})\n\n`;
    }
    case "link_preview": {
      return `[${block.link_preview.url}](${block.link_preview.url})\n\n`;
    }
    case "synced_block": {
      // Render the children of the original synced block
      if (block.synced_block && block.synced_block.synced_from) {
        const originalId = block.synced_block.synced_from.block_id;
        const res = await client.blocks.retrieve({ block_id: originalId });
        const childBlocks: any[] = [];
        if ((res as any).has_children) {
          const list = await client.blocks.children.list({ block_id: originalId });
          for (const child of list.results) {
            childBlocks.push(child);
          }
        }
        return await renderBlocks(client, childBlocks, registry, options, depth);
      }
      return "";
    }
    default: {
      // Fallback: render nothing but include a comment indicating unsupported type
      return `<!-- unsupported block type: ${block.type} -->\n`;
    }
  }
}