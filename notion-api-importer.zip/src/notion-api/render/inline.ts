import { RichTextItemResponse } from "@notionhq/client/build/src/api-endpoints";

/**
 * Convert an array of Notion rich text objects into a Markdown string. The
 * renderer preserves basic formatting such as bold, italic, underline,
 * strikethrough and code. Links are rendered as Markdown links. Mentions to
 * pages or databases are emitted in the form [[notion-id]]; these will be
 * resolved to Obsidian file names in a later pass.
 */
export function renderInline(
  texts: RichTextItemResponse[] | any[],
  registry: Map<string, string>
): string {
  let result = "";
  for (const t of texts) {
    if (!t) continue;
    let text = t.plain_text || "";
    if (t.href) {
      // External links
      text = `[${text}](${t.href})`;
    }
    // Process annotations (bold, italic, etc.)
    const ann = t.annotations || {};
    if (ann.code) text = `\`${text}\``;
    if (ann.bold) text = `**${text}**`;
    if (ann.italic) text = `*${text}*`;
    if (ann.strikethrough) text = `~~${text}~~`;
    if (ann.underline) text = `<u>${text}</u>`;
    // Mentions
    if (t.type === "mention") {
      const mention = t.mention;
      if (mention.type === "page" || mention.type === "database") {
        const id = mention.page?.id || mention.database?.id;
        if (id) {
          // Insert placeholder link; will be replaced in finalize pass
          text = `[[${id}]]`;
        }
      } else if (mention.type === "date") {
        const start = mention.date.start;
        const end = mention.date.end;
        text = start + (end ? `–${end}` : "");
      } else if (mention.type === "user") {
        // Render user name directly; Notion API returns user object separately
        const name = (mention.user as any)?.name || "(user)";
        text = name;
      }
    }
    result += text;
  }
  return result;
}