import { Client } from "@notionhq/client";
import { ImportOptions } from "../../types";
import { renderInline } from "./inline";

/**
 * Render a Notion table block into a Markdown table. Notion represents tables
 * as a parent block of type `table` whose children are `table_row` blocks. Each
 * row contains an array of cells, each cell being an array of rich text
 * objects. We convert the first row into the header and the remainder into
 * body rows. If there is no header row we still render a header with empty
 * cells to satisfy Markdown syntax.
 */
export async function renderTable(
  client: Client,
  tableBlock: any,
  rows: any[],
  registry: Map<string, string>,
  options: ImportOptions
): Promise<string> {
  if (!rows || rows.length === 0) return "";
  const headerCells = rows[0].table_row?.cells ?? [];
  const headers = headerCells.map((cell: any[]) => renderInline(cell, registry));
  const bodyRows = rows.slice(1).map(row => {
    const cells = row.table_row?.cells ?? [];
    return cells.map((cell: any[]) => renderInline(cell, registry));
  });
  // Build Markdown table: header, separator, rows
  let md = "| " + headers.join(" | ") + " |\n";
  md += "| " + headers.map(() => "---").join(" | ") + " |\n";
  for (const row of bodyRows) {
    md += "| " + row.join(" | ") + " |\n";
  }
  return md;
}