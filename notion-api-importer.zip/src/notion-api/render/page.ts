import { Client } from "@notionhq/client";
import { normalizePath } from "obsidian";
import * as fs from "fs-extra";
import * as path from "path";
import { PageStub, DatabaseStub, ImportOptions } from "../../types";
import { renderBlocks } from "./blocks";
import { mapProperties } from "../mapping/properties";
import { createSlug } from "../util";
import { mapDatabaseToBase } from "../mapping/bases";
import { downloadFile } from "../files";

/**
 * Render a Notion page into Markdown. Returns the generated Markdown string
 * and the slug used for the filename. The registry map is passed in to
 * resolve relations later; relations are emitted as placeholders of the form
 * [[notion-id]] which will be replaced in a final pass.
 */
export async function renderPage(
  client: Client,
  stub: PageStub,
  registry: Map<string, string>,
  options: ImportOptions
): Promise<{ markdown: string; slug: string }> {
  const page = await client.pages.retrieve({ page_id: stub.id });
  // Attempt to derive a slug from the page title if available
  let title = extractTitleFromPage(page);
  const slug = createSlug(title || stub.id);
  // Frontmatter: map all properties on the page
  const { frontmatter, relations } = mapProperties(page.properties || {}, options);
  // Fetch all block children recursively
  const blocks: any[] = await fetchBlockTree(client, page.id);
  const body = await renderBlocks(client, blocks, registry, options);
  // Assemble YAML frontmatter and body
  const yamlFrontmatter = toYaml(frontmatter);
  let content = `---\n${yamlFrontmatter}---\n\n${body}`;
  return { markdown: content, slug };
}

/**
 * Render an entire Notion database. This function iterates over each row in
 * the database, converts it into a Markdown note with frontmatter, and
 * generates a `.base` file to configure a table and card view for the
 * imported notes. The returned object contains the path of the folder
 * containing all note files and the base file name.
 */
export async function renderDatabase(
  client: Client,
  stub: DatabaseStub,
  vaultPath: string,
  registry: Map<string, string>,
  options: ImportOptions
): Promise<{ folder: string; baseFile: string }> {
  const database = await client.databases.retrieve({ database_id: stub.id });
  const dbSlug = createSlug(extractTitleFromDatabase(database) || stub.id);
  const folder = path.join(dbSlug);
  await fs.ensureDir(path.join(vaultPath, folder));
  // Query all rows in the database
  let cursor: string | undefined = undefined;
  do {
    const res: any = await client.databases.query({
      database_id: stub.id,
      start_cursor: cursor,
      page_size: 100
    });
    for (const row of res.results) {
      if (row.object === "page") {
        const { markdown, slug } = await renderPage(client, { id: row.id }, registry, options);
        const fileName = path.join(folder, slug + ".md");
        await fs.outputFile(path.join(vaultPath, fileName), markdown);
        registry.set(row.id, fileName);
      }
    }
    cursor = res.next_cursor ?? undefined;
  } while (cursor);
  // Create the .base file to describe views over the database
  const baseYaml = mapDatabaseToBase(database);
  const baseFile = path.join(folder, `${dbSlug}.base`);
  await fs.outputFile(path.join(vaultPath, baseFile), baseYaml);
  return { folder, baseFile };
}

/**
 * Recursively fetch the entire subtree of blocks under the given block ID.
 * This helper handles pagination and yields a flat array of blocks with
 * children embedded in the `children` property to simplify rendering.
 */
async function fetchBlockTree(client: Client, blockId: string): Promise<any[]> {
  const blocks: any[] = [];
  let cursor: string | undefined = undefined;
  do {
    const res: any = await client.blocks.children.list({
      block_id: blockId,
      start_cursor: cursor,
      page_size: 100
    });
    for (const block of res.results) {
      const child: any = { ...block };
      // Recursively fetch children for nested blocks (lists, toggles, etc.)
      if ((block.has_children ?? false) && block.id) {
        child.children = await fetchBlockTree(client, block.id);
      }
      blocks.push(child);
    }
    cursor = res.next_cursor ?? undefined;
  } while (cursor);
  return blocks;
}

function extractTitleFromPage(page: any): string | undefined {
  // Notion pages store their title in a property whose type is "title"
  for (const key of Object.keys(page.properties || {})) {
    const prop: any = page.properties[key];
    if (prop.type === "title") {
      const titleArr = prop.title as any[];
      if (titleArr && titleArr.length > 0) {
        return titleArr.map(t => t.plain_text).join("");
      }
    }
  }
  return undefined;
}

function extractTitleFromDatabase(db: any): string | undefined {
  const title = db.title as any[];
  if (title && title.length > 0) {
    return title.map((t: any) => t.plain_text).join("");
  }
  return undefined;
}

/**
 * Serialize a frontmatter object to YAML. We intentionally use a very simple
 * serializer rather than rely on YAML.stringify to avoid pulling in large
 * dependencies at runtime. Nested objects and arrays are supported.
 */
function toYaml(obj: any, indent: number = 0): string {
  const lines: string[] = [];
  const indentStr = (n: number) => "  ".repeat(n);
  for (const key of Object.keys(obj)) {
    const value = obj[key];
    if (value === undefined || value === null) continue;
    if (Array.isArray(value)) {
      if (value.length === 0) continue;
      lines.push(`${indentStr(indent)}${key}:`);
      for (const item of value) {
        if (typeof item === "object") {
          lines.push(`${indentStr(indent + 1)}-`);
          lines.push(toYaml(item, indent + 2));
        } else {
          lines.push(`${indentStr(indent + 1)}- ${serializeScalar(item)}`);
        }
      }
    } else if (typeof value === "object") {
      lines.push(`${indentStr(indent)}${key}:`);
      lines.push(toYaml(value, indent + 1));
    } else {
      lines.push(`${indentStr(indent)}${key}: ${serializeScalar(value)}`);
    }
  }
  return lines.join("\n");
}

function serializeScalar(value: any): string {
  if (typeof value === "string") {
    // Escape quotes and wrap strings containing colon or hash in quotes
    const needsQuotes = /[:#\n]/.test(value);
    const escaped = value.replace(/"/g, '\\"');
    return needsQuotes ? `"${escaped}"` : escaped;
  }
  return String(value);
}