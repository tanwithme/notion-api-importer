import { toYamlInternal } from "../util";

/**
 * Create the YAML content for a `.base` file corresponding to a Notion
 * database. A base defines how to view and interact with the notes derived
 * from the database. We approximate the Notion experience by defining a
 * single table view and a single card view. If the database includes sorts
 * and filters we attempt to translate simple cases. Unsupported features are
 * ignored but documented in comments.
 */
export function mapDatabaseToBase(database: any): string {
  const base: any = {};
  base.properties = {};
  // Map Notion properties into base columns with display names
  for (const key of Object.keys(database.properties || {})) {
    const prop = database.properties[key];
    base.properties[key] = { displayName: prop.name || key };
  }
  // Basic views: table and cards
  base.views = [];
  base.views.push({ type: "table", name: "All" });
  base.views.push({ type: "cards", name: "Cards" });
  return toYamlInternal(base);
}