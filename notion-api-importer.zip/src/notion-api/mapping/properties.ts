import { ImportOptions } from "../../types";

/**
 * Convert Notion properties object into two pieces: a YAML‑serializable
 * frontmatter object and a relations object keyed by property name. The
 * relations object records links to other pages or databases which will be
 * resolved in a later pass. Unsupported property types are ignored.
 */
export function mapProperties(
  properties: Record<string, any>,
  options: ImportOptions
): { frontmatter: any; relations: Record<string, string[]> } {
  const frontmatter: Record<string, any> = {};
  const relations: Record<string, string[]> = {};
  for (const key of Object.keys(properties)) {
    const prop = properties[key];
    switch (prop.type) {
      case "title": {
        const texts = prop.title as any[];
        const value = texts.map(t => t.plain_text).join("");
        frontmatter.title = value;
        break;
      }
      case "rich_text": {
        const texts = prop.rich_text as any[];
        const value = texts.map(t => t.plain_text).join("");
        frontmatter[key] = value;
        break;
      }
      case "number": {
        frontmatter[key] = prop.number;
        break;
      }
      case "select": {
        frontmatter[key] = prop.select?.name ?? null;
        if (options.mapSelectToTags) {
          // When mapping to tags, merge into tags array
          frontmatter.tags = frontmatter.tags || [];
          if (prop.select?.name) frontmatter.tags.push(prop.select.name);
          delete frontmatter[key];
        }
        break;
      }
      case "multi_select": {
        const names = (prop.multi_select as any[]).map(v => v.name);
        frontmatter[key] = names;
        if (options.mapSelectToTags) {
          frontmatter.tags = frontmatter.tags || [];
          frontmatter.tags.push(...names);
          delete frontmatter[key];
        }
        break;
      }
      case "checkbox": {
        frontmatter[key] = prop.checkbox;
        break;
      }
      case "date": {
        if (prop.date) {
          frontmatter[key] = prop.date.end
            ? { start: prop.date.start, end: prop.date.end }
            : prop.date.start;
        }
        break;
      }
      case "url": {
        frontmatter[key] = prop.url;
        break;
      }
      case "email": {
        frontmatter[key] = prop.email;
        break;
      }
      case "phone_number": {
        frontmatter[key] = prop.phone_number;
        break;
      }
      case "people": {
        const people = (prop.people as any[]) || [];
        const names = people.map(p => p.name || p.id);
        frontmatter[key] = names;
        break;
      }
      case "files": {
        const files = (prop.files as any[]) || [];
        const urls: string[] = [];
        for (const file of files) {
          if (file.type === "file") {
            urls.push(file.file.url);
          } else if (file.type === "external") {
            urls.push(file.external.url);
          }
        }
        frontmatter[key] = urls;
        break;
      }
      case "relation": {
        const rel = (prop.relation as any[]) || [];
        relations[key] = rel.map(item => item.id);
        frontmatter[key] = rel.map(item => `[[${item.id}]]`);
        break;
      }
      case "rollup": {
        // Flatten rollup as plain text if available; otherwise ignore
        const array = prop.rollup?.array;
        const number = prop.rollup?.number;
        const date = prop.rollup?.date;
        if (array) {
          frontmatter[key] = array.map((v: any) => v.plain_text ?? v.number ?? v.date);
        } else if (number !== undefined) {
          frontmatter[key] = number;
        } else if (date) {
          frontmatter[key] = date.start;
        }
        break;
      }
      case "formula": {
        // Preserve original expression and result
        frontmatter[key] = {
          expression: prop.formula?.expression ?? null,
          result: prop.formula?.number ?? prop.formula?.string ?? prop.formula?.boolean ?? null
        };
        break;
      }
      default: {
        // Unknown or unsupported property types are skipped
        break;
      }
    }
  }
  return { frontmatter, relations };
}