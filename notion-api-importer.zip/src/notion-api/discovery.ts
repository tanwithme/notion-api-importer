import { Client } from "@notionhq/client";
import { DiscoveryResult, PageStub, DatabaseStub } from "../types";

/**
 * Discover all pages and databases accessible to the given integration token.
 * The Notion search endpoint can return both pages and databases when no
 * filter is provided. To ensure we capture both types we perform two
 * searches: one filtered for pages and one for databases. Results are
 * returned as simple stubs containing only the ID and optionally a title.
 */
export async function discoverWorkspace(client: Client): Promise<DiscoveryResult> {
  const pages: PageStub[] = [];
  const databases: DatabaseStub[] = [];
  // Helper to collect results from paginated search
  async function collect(filter: { value: string; property: string }) {
    let cursor: string | undefined = undefined;
    do {
      const res: any = await client.search({
        filter,
        start_cursor: cursor,
        page_size: 100
      });
      for (const result of res.results) {
        if (result.object === "page") {
          pages.push({ id: result.id });
        } else if (result.object === "database") {
          databases.push({ id: result.id });
        }
      }
      cursor = res.next_cursor ?? undefined;
    } while (cursor);
  }
  // search for pages
  await collect({ property: "object", value: "page" });
  // search for databases
  await collect({ property: "object", value: "database" });
  return { pages, databases };
}