/**
 * Create a filesystem‑safe slug from an arbitrary string. We lower‑case,
 * replace whitespace with hyphens, and strip characters that are not
 * alphanumeric, hyphens or underscores. If the result is empty we return
 * the original input.
 */
export function createSlug(input: string): string {
  const slug = input
    .toLowerCase()
    .trim()
    .replace(/[\s]+/g, "-")
    .replace(/[^a-z0-9\-_]+/g, "");
  return slug || input;
}

/**
 * Serialize an object into YAML. This helper is used in multiple modules to
 * avoid importing a full YAML library at runtime. The implementation is
 * intentionally basic and supports nested objects and arrays. Strings
 * containing special characters are quoted. Undefined values are skipped.
 */
export function toYamlInternal(obj: any, indent: number = 0): string {
  const lines: string[] = [];
  const indentStr = (n: number) => "  ".repeat(n);
  for (const key of Object.keys(obj)) {
    const value = obj[key];
    if (value === undefined || value === null) continue;
    if (Array.isArray(value)) {
      if (value.length === 0) continue;
      lines.push(`${indentStr(indent)}${key}:`);
      for (const item of value) {
        if (typeof item === "object" && item !== null) {
          lines.push(`${indentStr(indent + 1)}-`);
          lines.push(toYamlInternal(item, indent + 2));
        } else {
          lines.push(`${indentStr(indent + 1)}- ${serializeScalar(item)}`);
        }
      }
    } else if (typeof value === "object") {
      lines.push(`${indentStr(indent)}${key}:`);
      lines.push(toYamlInternal(value, indent + 1));
    } else {
      lines.push(`${indentStr(indent)}${key}: ${serializeScalar(value)}`);
    }
  }
  return lines.join("\n");
}

function serializeScalar(value: any): string {
  if (typeof value === "string") {
    // Wrap strings containing colon, hash or newline in quotes
    const needsQuotes = /[:#\n]/.test(value);
    const escaped = value.replace(/"/g, '\\"');
    return needsQuotes ? `"${escaped}"` : escaped;
  }
  return String(value);
}