import * as fs from "fs-extra";
import * as path from "path";
import * as https from "https";
import { URL } from "url";
import { Client } from "@notionhq/client";
import { ImportOptions } from "../types";

/**
 * Download a file referenced in a Notion block or property. The returned
 * string is the relative path to the saved file inside the attachments
 * directory. If the file cannot be downloaded the remote URL is returned
 * instead so the importer still produces a valid link.
 */
export async function downloadFile(
  client: Client,
  file: any,
  options: ImportOptions
): Promise<string> {
  // Determine remote URL and filename
  const url = file.file?.url ?? file.external?.url;
  if (!url) return "";
  const parsed = new URL(url);
  const fileName = path.basename(parsed.pathname || parsed.href.split("?")[0]);
  // Determine attachments directory; default to "attachments" at vault root
  const attachmentsDir = options && (options as any).attachmentsDir ? (options as any).attachmentsDir : "attachments";
  // Ensure directory exists
  await fs.ensureDir(path.join((options as any).vaultPath || ".", attachmentsDir));
  const destRelative = path.join(attachmentsDir, fileName);
  const dest = path.join((options as any).vaultPath || ".", destRelative);
  return new Promise((resolve) => {
    const stream = fs.createWriteStream(dest);
    https
      .get(url, (response) => {
        response.pipe(stream);
        stream.on("finish", () => {
          stream.close();
          resolve(destRelative);
        });
      })
      .on("error", (_err) => {
        // fall back to remote URL on error
        resolve(url);
      });
  });
}