import { App, normalizePath, TFile } from "obsidian";
import { Client } from "@notionhq/client";
import pLimit from "p-limit";
import * as fs from "fs-extra";
import * as path from "path";
import { createNotionClient } from "./notion-api/client";
import { discoverWorkspace } from "./notion-api/discovery";
import { renderPage, renderDatabase } from "./notion-api/render/page";
import { finalizeLinks } from "./notion-api/finalize/links";
import { ImportOptions } from "./types";

/**
 * The main entry point for importing content from Notion. This function
 * orchestrates the discovery of pages and databases, converts each item into
 * Markdown or Base files, downloads attachments, writes them to the vault, and
 * finally resolves cross‑note links. Progress information is written to a
 * human‑readable log file in the vault root.
 */
export async function importFromNotion(
  app: App,
  vaultPath: string,
  token: string,
  options: ImportOptions
): Promise<void> {
  const notion = createNotionClient(token);
  const logFile = path.join(vaultPath, "notion-import.log");
  const log = (msg: string) => {
    console.log(msg);
    fs.appendFileSync(logFile, msg + "\n");
  };

  log(`Notion import started at ${new Date().toISOString()}`);

  // 1. Discover all pages and databases available to the integration
  log("Discovering pages and databases");
  const discovery = await discoverWorkspace(notion);
  log(`Found ${discovery.pages.length} pages and ${discovery.databases.length} databases`);

  // 2. Render pages and write Markdown files
  const registry = new Map<string, string>();
  const limit = pLimit(3); // limit concurrency to 3 to respect Notion rate limits
  for (const page of discovery.pages) {
    await limit(async () => {
      const { markdown, slug } = await renderPage(notion, page, registry, options);
      const fileName = slug + ".md";
      const filePath = path.join(vaultPath, normalizePath(fileName));
      await fs.outputFile(filePath, markdown);
      registry.set(page.id, fileName);
      log(`Page ${page.id} saved to ${fileName}`);
    });
  }

  // 3. Render databases into notes and bases
  for (const db of discovery.databases) {
    await limit(async () => {
      const result = await renderDatabase(notion, db, vaultPath, registry, options);
      registry.set(db.id, result.folder);
      log(`Database ${db.id} imported to folder ${result.folder}`);
    });
  }

  // 4. Finalize cross‑note links
  log("Resolving cross‑note links");
  await finalizeLinks(vaultPath, registry);
  log("Notion import completed");
}