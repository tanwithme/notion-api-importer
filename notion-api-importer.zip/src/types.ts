/**
 * Options controlling how the Notion import behaves. Many of these options
 * correspond to checkboxes or dropdowns in the UI. For this proof‑of‑concept
 * implementation the interface is intentionally minimal; you can extend it as
 * your importer grows.
 */
export interface ImportOptions {
  /**
   * A map of database IDs or page IDs to booleans controlling whether they
   * should be imported. If empty or undefined, all content visible to the
   * integration will be imported.
   */
  includeIds?: Record<string, boolean>;
  /**
   * If true, select and multi‑select properties will be mapped to tags in the
   * note frontmatter. When false they are stored as plain lists of strings.
   */
  mapSelectToTags?: boolean;
  /**
   * When true, create a People folder and generate notes for each mentioned
   * person. The importer will link mentions to those files. When false,
   * people names are rendered inline as plain text.
   */
  createPeopleNotes?: boolean;

  /**
   * Absolute path to the Obsidian vault. This is set internally by the importer
   * before downloading attachments. Users typically do not need to configure
   * this manually.
   */
  vaultPath?: string;
  /**
   * Name of the folder inside the vault where attachments downloaded from
   * Notion (files and images) will be saved. Defaults to "attachments".
   */
  attachmentsDir?: string;
}

/**
 * Lightweight representation of a page returned during discovery. Only
 * includes the page ID and a title if known.
 */
export interface PageStub {
  id: string;
  title?: string;
}

/**
 * Lightweight representation of a database returned during discovery.
 */
export interface DatabaseStub {
  id: string;
  title?: string;
}

/**
 * Result of discovering a Notion workspace. Contains separate lists of pages
 * and databases. Additional metadata may be added in the future.
 */
export interface DiscoveryResult {
  pages: PageStub[];
  databases: DatabaseStub[];
}